﻿using System;
using System.Collections.Generic;

namespace Library_Manager.Models;

public partial class TTaiLieuTacGium
{
    public string MaTl { get; set; } = null!;

    public string MaTg { get; set; } = null!;

    public string? VaiTro { get; set; }

    public virtual TTacGium MaTgNavigation { get; set; } = null!;

    public virtual TTaiLieu MaTlNavigation { get; set; } = null!;
}
