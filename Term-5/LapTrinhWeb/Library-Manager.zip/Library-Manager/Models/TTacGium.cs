﻿using System;
using System.Collections.Generic;

namespace Library_Manager.Models;

public partial class TTacGium
{
    public string MaTg { get; set; } = null!;

    public string HoDem { get; set; } = null!;

    public string Ten { get; set; } = null!;

    public virtual ICollection<TTaiLieuTacGium> TTaiLieuTacGia { get; set; } = new List<TTaiLieuTacGium>();
}
